# Mini-Picture-Instagram-Clone
Instagram style SPA for Miniature model painters to upload pictures of their work, React project using Firebase
